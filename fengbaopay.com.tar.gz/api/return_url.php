<?php
/* *
 * 功能：微极速支付异步通知页面
 * 说明：
 * 以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 * 该代码仅供学习和研究支付宝接口使用，只是提供一个参考。


 *************************页面功能说明*************************
 * 创建该页面文件时，请留心该页面文件中无任何HTML代码及空格。
 * 该页面不能在本机电脑测试，请到服务器上做测试。请确保外部可以访问该页面。
 * 该页面调试工具请使用写文本函数logResult，该函数已被默认关闭，见alipay_notify_class.php中的函数verifyNotify
 */
require_once("qsclass.php");
//计算得出通知验证结果
//$alipayNotify = new AlipayNotify($alipay_config);
//$verify_result = $alipayNotify->verifyNotify();
$qsclass = new qsclass();
$verify_result = $qsclass->verifyNotify();
if($verify_result) {//验证成功
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//请在这里加上商户的业务逻辑程序代

	
	//——请根据您的业务逻辑来编写程序（以下代码仅作参考）——
	
    //获取支付宝的通知返回参数，可参考技术文档中服务器异步通知参数列表
	
	//商户订单号

	$out_trade_no = $verify_result['out_trade_no'];

	//倾世CMS支付交易号

	$trade_no = $verify_result['trade_no'];

	//交易状态
	$trade_status = $verify_result['trade_status'];

	//交易金额
	$money = $verify_result['money'];
	//支付方式
	$type = $verify_result['type'];

	if ($verify_result['trade_status'] == 'SUCCESS') {
		$qsclass->logResult('SUCCESS');
		//判断该笔订单是否在商户网站中已经做过处理
			//如果没有做过处理，根据订单号（out_trade_no）在商户网站的订单系统中查到该笔订单的详细，并执行商户的业务程序
			//请务必判断请求时的total_fee、seller_id与通知时获取的total_fee、seller_id为一致的
			//如果有做过处理，不执行商户的业务程序
				
		//注意：
		//付款完成后，支付宝系统发送该交易状态通知

    }

	//——请根据您的业务逻辑来编写程序（以上代码仅作参考）——
        
	echo "success";		//请不要修改或删除
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}else {
    //验证失败
	$qsclass->logResult('FAIL');
    echo "fail";
}
?>