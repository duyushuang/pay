<?php exit;?>a:9:{s:4:"time";s:2:"60";s:10:"time_vcode";s:3:"180";s:6:"server";s:29:"smtpout.asia.secureserver.net";s:4:"port";s:2:"80";s:8:"username";s:18:"service@vipmmm.com";s:5:"email";s:18:"service@vipmmm.com";s:8:"password";s:6:"abc123";s:8:"isGetPwd";s:1:"1";s:9:"getPwdStr";s:80:"你好，{nickname}：
你的{webName}恢复代码是{vcode}
{webName}{webUrl}";}